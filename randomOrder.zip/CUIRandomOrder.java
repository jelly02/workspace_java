import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 * <pre>
 * 복불복 순서 정하기
 * </pre>
 *  
 * @author 임경혜
 * @version ver.1.0
 * @since jdk1.8
 */
public class CUIRandomOrder {
	
	public static int[] randomCount;
	public static int uniqueLength;
	
	public static void main(String[] args) {
		System.out.println("------------------------------");
		System.out.println("** 복불복 순서정하기 **");
		System.out.println("[팀원의 순서는 사전에 순번을 정해놓으세요]");
		System.out.println("------------------------------");
		
		System.out.print("인원(팀)수 입력 : ");
		int length = inputNumber();
		
		randomCount = new int[length];
		int randomNo = -1;
		boolean isUniqueCheck = false;
		for (int index = 0; uniqueLength < randomCount.length; index++) {
			randomNo = getRandomNo(length);
			isUniqueCheck = isUnique(randomNo);
			if (isUniqueCheck) {
				continue;
			}
			randomCount[uniqueLength++] = randomNo;
		}
		
		System.out.println();
		System.out.println("------------------------------");
		System.out.println("** 복불복 순서 입니다 **");
		System.out.println("[인생도 때로는 복불복이랍니다 ^^]");
		System.out.println("------------------------------");
		for (int index = 0; index < randomCount.length; index++) {
			System.out.println("[" + (index + 1) + "] "+ randomCount[index] + " 팀[팀원]");
		}
	}
	
	public static boolean isUnique(int randomNo) {
		for (int index = 0; index < uniqueLength; index++) {
			if (randomCount[index] == randomNo) {
				return true;
			}
		}
		
		return false;
	}
	
	public static int getRandomNo(int bound) {
		Random random = new Random((long)(Math.random() * System.nanoTime()));
		return random.nextInt(bound) + 1;
	}

	/**
	 * 문자열 입력 반환
	 * @return 입력 문자열
	 */
	public static String inputString() {
		String data = null;
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			data = in.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;
	}
	
	/**
	 * 숫자 입력 반환
	 * @return 입력 정수형 숫자
	 */
	public static int inputNumber() {
		String data = null;
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			data = in.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Integer.parseInt(data);
	}
	
}
